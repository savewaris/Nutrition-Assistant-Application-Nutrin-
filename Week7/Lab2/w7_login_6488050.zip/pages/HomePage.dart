import 'package:flutter/material.dart';
class HomePage extends StatefulWidget {
HomePage ({ Key ? key }) : super ( key : key );
@override
_HomePageState createState () => _HomePageState () ;
}
class _HomePageState extends State < HomePage > {
  final _formKey = GlobalKey < FormState >() ;
  late final TextEditingController _emailController;
  late final TextEditingController _passwordController;
@override
void initState () {
super . initState () ;
_emailController = TextEditingController () ;
_passwordController = TextEditingController () ;
}
Widget build ( BuildContext context ) {
return Scaffold (
appBar : AppBar (
title : Text ('HomePage') ,
) ,
body : Center (
child : Column (
mainAxisAlignment : MainAxisAlignment . center ,
children : [ Text ('HomePage')],
) ,
));
}
}