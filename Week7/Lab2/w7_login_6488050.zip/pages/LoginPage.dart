import 'package:flutter/material.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import 'package:form_builder_validators/form_builder_validators.dart';

class LoginPage extends StatefulWidget {
LoginPage ({ Key ? key }) : super ( key : key );
@override
_LoginPageState createState () => _LoginPageState () ;
}
class _LoginPageState extends State < LoginPage > {
  final _formKey = GlobalKey<FormBuilderState>() ;
@override
Widget build ( BuildContext context ) {
return Scaffold (
body : Container (
child : Center (
child : SingleChildScrollView (
child : Column (
children : [
Image (
image : AssetImage ('assets/profile.png'),
height : 100 ,
) ,
Text ('Login',
style : TextStyle ( fontSize : 20 , color : Colors . blue )) ,
Padding (
padding : EdgeInsets .all (10) ,
child : FormBuilder (
key : _formKey ,
initialValue : {'username':'', 'password': ''},
child : Column (
children : [
FormBuilderTextField (
name : 'username',
decoration : InputDecoration (
labelText : 'Email',
filled : true ,
) ,
validator : FormBuilderValidators.compose ([
FormBuilderValidators.required (errorText : 'please insert email') ,
FormBuilderValidators.email() ,
]) ,
keyboardType: TextInputType.emailAddress ,
) ,
SizedBox ( height: 15) ,
FormBuilderTextField (
name:'password',
obscureText : true ,
decoration : InputDecoration (
labelText : 'Password',
filled : true ,
) ,
validator : FormBuilderValidators.compose ([
FormBuilderValidators.required (errorText : 'Please insert password') ,
FormBuilderValidators.minLength(8,errorText : 'Min length 8 characters') ,
]) ,
) ,
SizedBox (
height : 20 ,
) ,
SizedBox (
child : MaterialButton (
onPressed : () {
_formKey . currentState !. save () ;
if ( _formKey . currentState !. validate () ) {
// open Homepage ( pass launcher )
Navigator . pushNamed ( context , '/launcher') ;
} else {
print ("Validation failed") ;
}
},
child : Text ("Login",
style : TextStyle ( color : Colors . blue )) ,
) ,
) ,
SizedBox ( height : 15) ,
Row (
children: [
Expanded (
child: MaterialButton (
onPressed: () {
// open Homepage
Navigator.pushNamed ( context , '/register') ;
},
child : Text ('Register User',
style : TextStyle ( color : Colors . blue )) ,
))
],
)
],
) ,
) ,
)
],
) ,
) ,
) ,
) ,
);
}
}
